import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resumeupload',
  templateUrl: './resumeupload.component.html',
  styleUrls: ['./resumeupload.component.css']
})
export class ResumeuploadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
