import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { ContactComponent } from './Contact/Contact.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { JobsearchComponent } from './jobsearch/jobsearch.component';
import { NewComponent } from './new/new.component';
import { ResumeuploadComponent } from './resumeupload/resumeupload.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    SignupComponent,
    ContactComponent,
    FeedbackComponent,
    JobsearchComponent,
    NewComponent,
    ResumeuploadComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
